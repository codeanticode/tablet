i686-w64-mingw32-dlltool -k -d Wintab32.def -l libWintab32.a
