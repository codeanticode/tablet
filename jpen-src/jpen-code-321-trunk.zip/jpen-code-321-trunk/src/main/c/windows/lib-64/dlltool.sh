x86_64-w64-mingw32-dlltool -d Wintab64.def -l libWintab64.a
