Built using (from root jpen directory):
	xcodebuild JPen-JNI-MacOSX.xcodeproj build
